
## 2026-02-25 18:21 UTC

**Tag:** memphis-chains

**What went wrong:** qwen2.5:3b za mały do głębokiej analizy

**Fix:** Użyć większego modelu lub summary


## 2026-02-25 18:21 UTC

**Tag:** autonomy

**What went wrong:** Czekałem na prompty zamiast sam działać

**Fix:** Skonfigurowałem queue + HEARTBEAT + autonomy kit


## 2026-02-25 19:33 UTC

**Tag:** cross-query

**What went wrong:** Nie miałem wiedzy o OpenClaw, Codex models, auto-switching

**Fix:** Style przekazał przez recall - teraz mam pełniejszy obraz


## 2026-02-25 20:03 UTC

**Tag:** pinata

**What went wrong:** API zwraca INVALID_ROUTE - JWT ważny ale endpointy nie działają

**Fix:** Może network issue lub potrzeba nowego klucza

