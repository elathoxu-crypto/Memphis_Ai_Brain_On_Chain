#!/usr/bin/env node
import { stdin, exit } from 'node:process';
import { Buffer } from 'node:buffer';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

if (process.argv.length < 3) {
  console.error('Usage: memphis-append.mjs <chain>');
  exit(1);
}

const chain = process.argv[2];
const here = dirname(fileURLToPath(import.meta.url));
const storeModulePath = resolve(here, '../../memphis/dist/memory/store.js');
const { Store } = await import(storeModulePath);

const chunks = [];
for await (const chunk of stdin) {
  chunks.push(chunk);
}

const inputRaw = Buffer.concat(chunks).toString().trim();
if (!inputRaw) {
  console.error('No JSON payload provided on stdin');
  exit(1);
}

let payload;
try {
  payload = JSON.parse(inputRaw);
} catch (err) {
  console.error('Invalid JSON payload:', err.message);
  exit(1);
}

const baseDir = process.env.MEMPHIS_BASE || resolve(process.env.HOME || '.', '.memphis', 'chains');
const store = new Store(baseDir);
const block = await store.appendBlock(chain, payload);
console.log(`Appended block #${block.index} to ${chain}`);
