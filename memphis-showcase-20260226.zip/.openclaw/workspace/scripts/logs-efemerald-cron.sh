#!/usr/bin/env bash
# Wrapper for cron/systemd to collect and optionally burn logs-efemerald snapshots.
# Run with either --collect or --burn (or both sequentially).

set -euo pipefail

cd "$(dirname "$0")/.."

collect() {
  echo "[logs-efemerald-cron] collecting..."
  ./scripts/logs-efemerald-collect.mjs || echo "[logs-efemerald-cron] collect failed"
}

burn() {
  echo "[logs-efemerald-cron] burning..."
  ./scripts/logs-efemerald-burn.sh || echo "[logs-efemerald-cron] burn failed"
}

DO_COLLECT=0
DO_BURN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --collect)
      DO_COLLECT=1
      shift
      ;;
    --burn)
      DO_BURN=1
      shift
      ;;
    --help|-h)
      cat <<'EOF'
Usage: logs-efemerald-cron.sh [--collect] [--burn]
Typical cron usage:
  */5 * * * * /path/scripts/logs-efemerald-cron.sh --collect >> ~/.logs-efemerald.cron.log 2>&1
  5 * * * *   /path/scripts/logs-efemerald-cron.sh --burn >> ~/.logs-efemerald.cron.log 2>&1
EOF
      exit 0
      ;;
    *)
      echo "Unknown flag: $1" >&2
      exit 1
      ;;
  esac
done

[[ $DO_COLLECT -eq 0 && $DO_BURN -eq 0 ]] && DO_COLLECT=1

[[ $DO_COLLECT -eq 1 ]] && collect
[[ $DO_BURN -eq 1 ]] && burn
