#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HEARTBEAT_FILE="$ROOT_DIR/HEARTBEAT.md"
QUEUE_FILE="$ROOT_DIR/tasks/QUEUE.md"
SYNC_SCRIPT="$ROOT_DIR/memphis-sync.sh"
OUTPUT_DIR="$ROOT_DIR/.cache"

DRY_RUN=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run)
      DRY_RUN=1
      shift
      ;;
    --help|-h)
      cat <<'EOF'
heartbeat-sync.sh
------------------
Collects the current HEARTBEAT + queue snapshot and optionally uploads it to Pinata
via memphis-sync.sh.

Usage:
  ./scripts/heartbeat-sync.sh [--dry-run]

Flags:
  --dry-run   Build the payload but skip uploading (prints JSON to stdout)
EOF
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      exit 1
      ;;
  esac
done

if [[ ! -f "$HEARTBEAT_FILE" ]]; then
  echo "Missing HEARTBEAT file at $HEARTBEAT_FILE" >&2
  exit 1
fi

if [[ ! -f "$QUEUE_FILE" ]]; then
  echo "Missing queue file at $QUEUE_FILE" >&2
  exit 1
fi

if [[ ! -x "$SYNC_SCRIPT" ]]; then
  echo "memphis-sync.sh must exist and be executable" >&2
  exit 1
fi

mkdir -p "$OUTPUT_DIR"
TMP_PAYLOAD="$(mktemp "$OUTPUT_DIR/heartbeat-sync.XXXXXX.json")"

HB_PATH="$HEARTBEAT_FILE" QUEUE_PATH="$QUEUE_FILE" node <<'NODE' > "$TMP_PAYLOAD"
const fs = require('fs');
const heartbeatPath = process.env.HB_PATH;
const queuePath = process.env.QUEUE_PATH;

const read = (p) => (p && fs.existsSync(p)) ? fs.readFileSync(p, 'utf8') : '';

const payload = {
  type: 'heartbeat.sync',
  timestamp: new Date().toISOString(),
  heartbeat: read(heartbeatPath),
  queue: read(queuePath),
  host: process.env.HOSTNAME || process.env.USER || 'unknown',
};

console.log(JSON.stringify(payload));
NODE

if [[ $DRY_RUN -eq 1 ]]; then
  cat "$TMP_PAYLOAD"
  rm -f "$TMP_PAYLOAD"
  exit 0
fi

PAYLOAD_JSON="$(cat "$TMP_PAYLOAD")"
NAME="heartbeat_sync_$(date +%Y%m%d_%H%M%S)"
CID=$("$SYNC_SCRIPT" upload "$PAYLOAD_JSON" "$NAME" | awk '/CID:/ {print $2}')

if [[ -z "$CID" ]]; then
  echo "Failed to upload heartbeat payload" >&2
  exit 1
fi

echo "Heartbeat sync uploaded: $CID"
echo "$CID" > "$OUTPUT_DIR/heartbeat-sync.last-cid"

rm -f "$TMP_PAYLOAD"
