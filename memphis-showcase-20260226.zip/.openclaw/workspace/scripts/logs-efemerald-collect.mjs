#!/usr/bin/env node
import { execSync } from 'node:child_process';
import { hostname, userInfo } from 'node:os';
import { resolve } from 'node:path';
import { existsSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';

const TTL_SECONDS = parseInt(process.env.LOGS_EFEMERALD_TTL ?? '300', 10);
const here = fileURLToPath(new URL('.', import.meta.url));
const candidateStorePaths = [
  process.env.MEMPHIS_STORE_MODULE,
  resolve(here, '../../memphis/dist/memory/store.js'),
  resolve(process.env.HOME || '.', 'memphis', 'dist', 'memory', 'store.js'),
].filter(Boolean);

const storeModulePath = candidateStorePaths.find((p) => existsSync(p));
if (!storeModulePath) {
  console.error('Unable to locate memphis store.js. Set MEMPHIS_STORE_MODULE to override.');
  process.exit(1);
}

const { Store } = await import(pathToFileURL(storeModulePath));

function run(cmd, options = {}) {
  try {
    const output = execSync(cmd, {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
      ...options,
    });
    return output.trim();
  } catch (err) {
    const stderr = err.stderr?.toString().trim();
    return `ERROR(${cmd}): ${stderr || err.message}`;
  }
}

const timestamp = new Date().toISOString();
const host = hostname();
const user = userInfo().username;

const memphisStatus = run('FORCE_COLOR=0 memphis status');
const openclawCommands = run('tail -n 200 ~/.openclaw/logs/commands.log');
const configAudit = run('tail -n 200 ~/.openclaw/logs/config-audit.jsonl');
const heartbeat = run('tail -n 200 HEARTBEAT.md', { cwd: resolve(here, '..') });

const payload = {
  timestamp,
  origin: 'logs-efemerald/collect',
  severity: 'info',
  ttl_seconds: TTL_SECONDS,
  host,
  user,
  streams: {
    memphisStatus,
    openclawCommands,
    configAudit,
    heartbeat,
  },
};

const baseDir = process.env.MEMPHIS_BASE || resolve(process.env.HOME || '.', '.memphis', 'chains');
const store = new Store(baseDir);
await store.appendBlock('logs-efemerald', {
  type: 'ops',
  content: `logs-efemerald snapshot @ ${timestamp}`,
  tags: ['logs', 'logs-efemerald', 'collect'],
  data: payload,
});

console.log(`[logs-efemerald] captured snapshot at ${timestamp} (host=${host})`);
