#!/usr/bin/env bash
set -euo pipefail

CHAIN_DIR="$HOME/.memphis/chains/logs-efemerald"
ARCHIVE_BASE="$HOME/.memphis/trash/logs-efemerald"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

if [[ -d "$CHAIN_DIR" && -n "$(ls -A "$CHAIN_DIR" 2>/dev/null)" ]]; then
  mkdir -p "$ARCHIVE_BASE"
  ARCHIVE_DIR="$ARCHIVE_BASE/$TIMESTAMP"
  mv "$CHAIN_DIR" "$ARCHIVE_DIR"
  echo "Archived logs to $ARCHIVE_DIR"
else
  echo "No logs to archive"
fi

mkdir -p "$CHAIN_DIR"
chmod 700 "$CHAIN_DIR"
echo "logs-efemerald chain reset"
