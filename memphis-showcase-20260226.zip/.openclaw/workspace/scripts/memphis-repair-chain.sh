#!/usr/bin/env bash
set -euo pipefail

CHAIN="$1"
LOG_DIR="$HOME/.openclaw/workspace/logs/memphis"
mkdir -p "$LOG_DIR"
LOGFILE="$LOG_DIR/repair-${CHAIN}-$(date +%Y%m%d_%H%M%S).log"

echo "[memphis-repair] $(date) Running repair for $CHAIN" | tee -a "$LOGFILE"
if memphis repair --chain "$CHAIN" 2>&1 | tee -a "$LOGFILE"; then
  echo "[memphis-repair] repair ok" | tee -a "$LOGFILE"
else
  echo "[memphis-repair] repair failed" | tee -a "$LOGFILE"
fi

echo "[memphis-repair] verify" | tee -a "$LOGFILE"
if memphis verify --chain "$CHAIN" 2>&1 | tee -a "$LOGFILE"; then
  echo "[memphis-repair] verify ok" | tee -a "$LOGFILE"
else
  echo "[memphis-repair] verify failed" | tee -a "$LOGFILE"
fi
