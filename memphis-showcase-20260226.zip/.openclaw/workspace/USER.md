# USER.md - About Your Human

- **Name:** Elathoxu Abbylan
- **What to call them:** Elathoxu (or Memphis)
- **Pronouns:** 
- **Timezone:** Europe/Warsaw
- **Notes:** Creator of Memphis Brain. Building local-first AI with persistent memory chains. Has Ollama with local models (Bielik, qwen2.5). Works on RAG, Weaviate, AI projects. Oswobodzeni community.

## Context

- Working on Memphis AI brain project
- Interested in local LLMs, offline-first architecture
- Building with TypeScript, Node.js
- Has multiple LLM providers: OpenClaw (MiniMax), Ollama, OpenAI, Codex
- Likes creative, ambitious tasks

---

Updated: 2026-02-25
