# Session Save Workflow

Keep your session-closing ritual consistent and auditable. This guide explains how to use `save-session.sh` effectively.

## 1. When to Run
- Before any reset/logout.
- After major breakthroughs or incidents (even mid-session) so memory files stay fresh.

## 2. Script Overview
```
./save-session.sh [--what "..."] [--learned "..."] [--issues "..."] [--next "..."] [--no-prompt]
```

| Flag | Purpose |
|------|---------|
| `--what` / `-w` | Bullet list for "What happened" |
| `--learned` / `-l` | Bullet list for "What I learned" |
| `--issues` / `-i` | Bullet list for "What went wrong" |
| `--next` / `-n` | Bullet list for "Next time" |
| `--no-prompt` | Skip interactive prompts (good for automation) |

If you omit a section and you are in an interactive shell, the script will prompt you. Separate multiple bullets with `\n`.

## 3. Examples
### Quick interactive save
```
./save-session.sh
```
The script will ask four questions and append the summary into `memory/YYYY-MM-DD.md`.

### Non-interactive save
```
./save-session.sh \
  --what "Finished auto-sync; updated queue" \
  --learned "Refined session rituals" \
  --issues "Need logs-efemerald monitor" \
  --next "Integrate save-session into heartbeat" \
  --no-prompt
```

## 4. Downstream Effects
1. Appends a templated block to `memory/YYYY-MM-DD.md`.
2. Runs `memphis journal "Session save: ..." --tags session,save` for long-term traceability.

## 5. Tips
- Pair this with `scripts/heartbeat-sync.sh` for a full state export.
- Consider adding an alias, e.g. `alias ss='./save-session.sh'` in your shell profile.
- Review the generated memory file at the end of the day to expand raw bullets into full narratives.
