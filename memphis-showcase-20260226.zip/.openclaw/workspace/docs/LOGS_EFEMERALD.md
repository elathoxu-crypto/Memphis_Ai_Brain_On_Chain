# logs-efemerald Pipeline

Ephemeral diagnostic logging for Memphis/OpenClaw. Use this when you need a short-lived TUI or status snapshot without polluting long-term memory.

## Components

| Piece | Path | Purpose |
|-------|------|---------|
| Chain | `~/.memphis/chains/logs-efemerald` | Stores transient log blocks (type=`ops`) |
| Collector | `scripts/logs-efemerald-collect.mjs` | Captures current status + log tails and appends a block |
| Burner | `scripts/logs-efemerald-burn.sh` | Archives & resets the chain (“burns” logs) |
| Helper | `scripts/memphis-append.mjs` | Generic Store writer used by other scripts |

## Usage

### Collect snapshot (recommended every ~5 minutes)
```
./scripts/logs-efemerald-collect.mjs
# lub
./scripts/logs-efemerald-cron.sh --collect
```
This gathers:
- `memphis status`
- Tail of `~/.openclaw/logs/commands.log`
- Tail of `~/.openclaw/logs/config-audit.jsonl`
- Last 200 lines of `HEARTBEAT.md`

Each block includes metadata (`timestamp`, `host`, `user`, `ttl_seconds`).

### Burn after review
```
./scripts/logs-efemerald-burn.sh
# lub
./scripts/logs-efemerald-cron.sh --burn
```
Moves the entire chain to `~/.memphis/trash/logs-efemerald/<timestamp>` and recreates an empty directory. Use this after reading the logs or when TTL (5m) expires.

## Workflow
1. Run the collector (manually, heartbeat job, or cron).
2. Inspect logs via `~/.memphis/chains/logs-efemerald/000XYZ.json` or a custom viewer.
3. Burn with `logs-efemerald-burn.sh` to keep diagnostics ephemeral.

## Notes
- Collector sets `LOGS_EFEMERALD_TTL` to 300s by default. Override via env var if needed.
- Blocks use `type: "ops"` and tags `logs`, `logs-efemerald`, `collect` which keeps SOUL validation happy.
- Burn archives the previous chain so you can recover if necessary.
- Consider wiring the collector + burner into your heartbeat checklist.

### Memphis module path
`scripts/logs-efemerald-collect.mjs` auto-detects the memphis install using this order:
1. `MEMPHIS_STORE_MODULE` env var (set to an explicit `.../dist/memory/store.js`)
2. Workspace-local `../../memphis/dist/memory/store.js`
3. System `~/memphis/dist/memory/store.js`

If none match, the script exits with instructions. Set `MEMPHIS_STORE_MODULE` when the memphis repo lives elsewhere.
