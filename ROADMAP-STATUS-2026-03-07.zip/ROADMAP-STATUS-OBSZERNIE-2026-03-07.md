# ROADMAP — co robimy i co już jest dowiezione (stan na 2026-03-07 04:31 CET)

## TL;DR
- **Zakres RM-001..RM-059: DONE**
- **Otwarte:** RM-060 i RM-061
- **Aktualnie in progress:** domknięcie M8 (single-node degraded mode) przez backlog replay + smoke offline/online

---

## 1) O co chodzi w tym roadmapie (cel biznesowo-techniczny)
Roadmap prowadzi od „pojedynczego bota i pamięci” do **stabilnego, odpornego runtime’u rozproszonego**:

1. Automatyzacja pamięci i operacji (M1)
2. Dashboard i operacyjna obserwowalność (M2)
3. Powiadomienia i digesty (M3)
4. Zaawansowane funkcje operacyjne (M4)
5. Kontrola kosztów modeli (M5)
6. Specyfikacja architektury distributed (M6)
7. Implementacja runtime distributed (M7)
8. Tryb zdegradowany, gdy drugi node jest offline (M8)

Finalnie: system ma nie padać przy braku executor node, tylko odkładać/replayować zadania i wracać do normalnej pracy po rejoinie.

---

## 2) Co już jest zrobione (obszernie, per milestone)

### M1 (RM-001..015) — Integration Automation
- Autorecall hook + fail-open (żeby odpowiedzi nie wisiały)
- Auto-journaling z regułami ALLOW/DENY i deduplikacją
- Share-sync scheduler (timer co 30 min) + retry/anti-spam
- Backup w heartbeat + checklista restore i test real restore
- `memphis chain add <name>` + walidacje + smoke
- Monitoring pokrycia embeddings + alert progowy
- Formalne domknięcie sprintu

**Efekt:** pamięć i maintenance są zautomatyzowane, odtwarzalne i monitorowane.

### M2 (RM-016..022) — Dashboard Lite
- Decyzja stacku: Fastify + prosty frontend
- Endpointy: `/health`, `/status`, `/logs`, `/exec`
- Frontend live status/log stream
- Auth token + owner-only guard
- Smoke test + dokumentacja uruchomienia

**Efekt:** operacyjny podgląd systemu i bezpieczny dostęp do narzędzi runtime.

### M3 (RM-023..027) — Notifications
- Notification service (critical/error)
- Dedupe i rate-limit (anti-spam)
- Severity templates (`info/error/critical`)
- Email skeleton
- Daily digest E2E

**Efekt:** czytelne alerty i mniej szumu.

### M4 (RM-028..035) — Advanced Features
- Logs search + export JSON/CSV + statystyki
- Exec PTY + procesy + limity zasobów
- Cron management
- Monitoring kontenerów
- Service control safeguards
- Hardening + release checklist

**Efekt:** dojrzałe ops narzędzia i bezpieczniejsze operacje.

### M5 (RM-036..040) — Codex Cost Ops
- Ujednolicone ścieżki i workflow CI
- Preflight wyboru modelu + lokalny runbook
- Telemetria kosztowa + template weekly retro
- Guardrails budżetowe 80/90% + fallback policy
- Smoke codex usage pipeline (local + CI)

**Efekt:** kontrola kosztów i przewidywalność wydatków modelowych.

### M6 (RM-041..048) — Distributed Gateway MVP (specy)
- Kontrakty eventów `cmd/evt/sys`
- Minimalny state machine (`job/task/run/lease`)
- Registry+heartbeat, retry/dead-letter, file lock, E2E flow, routing matrix
- Smoke distributed MVP

**Efekt:** spójny kontrakt i architektura przed implementacją runtime.

### M7 (RM-049..056) — Distributed Runtime Implementation
- Szkielet runtime (`gateway-runtime/`)
- Walidacja envelope + subject router
- In-memory state store + lifecycle guards
- Registry heartbeat transitions online/degraded/offline
- Lease manager + retry + dead-letter
- Path lock manager + blocked handling
- E2E simulation i full distributed smoke

**Efekt:** działający runtime orchestration z testami smoke.

### M8 (RM-057..061) — Single-Node Degraded Mode
- RM-057 DONE: degraded scheduling (deferred queue zamiast fail)
- RM-058 DONE: fallback executor lane na PC1 (small tasks)
- RM-059 DONE: node-b rejoin script
- RM-060 TODO: backlog replay po powrocie node-b
- RM-061 TODO: smoke flow offline→online resume

**Efekt obecny:** system już degraduje się miękko i ma fallback; brakuje pełnego replay + final smoke końcowego scenariusza.

---

## 3) Co robię TERAZ (04:31 CET)
Pracuję nad domknięciem M8:

### RM-060 — Backlog replay on node-b return
Cel: gdy node-b wraca online/rejoin, deferred backlog ma być deterministycznie przepchnięty do kolejki wykonawczej.

Plan implementacyjny:
1. Detect recovery signal po heartbeat/rejoin
2. Odczyt deferred queue
3. Requeue wg priorytetu/czasu + idempotency guard
4. Aktualizacja stanów task/run
5. Telemetria i logi replay (`count`, `duration`, `errors`)

### RM-061 — Offline/Online smoke flow
Cel: automatyczny test końcowy scenariusza:
`offline defer -> online rejoin -> replay -> resume`

Plan testowy:
1. Zasymulować offline executor node
2. Potwierdzić, że taski idą do deferred (bez hard fail)
3. Zasymulować rejoin node-b
4. Potwierdzić replay i przejście do queued/running/done
5. Zwrócić jednoznaczny marker PASS

---

## 4) Gdzie to jest w repo (najważniejsze ścieżki)
- `ROADMAP-MASTER-QUEUE.md` — źródło prawdy statusu RM
- `gateway-runtime/src/scheduler/index.mjs` — kolejki, degraded scheduling
- `gateway-runtime/src/scheduler/fallback-executor.mjs` — fallback lane (RM-058)
- `gateway-runtime/scripts/node-rejoin.sh` — rejoin (RM-059)
- `gateway-runtime/scripts/smoke-rm05x.mjs` — smoke testy etapowe
- `gateway-runtime/scripts/smoke-distributed-runtime.mjs` — pełny smoke runtime

---

## 5) Definicja „dowiezione” dla końcówki roadmapy
Za zamknięte M8 uznajemy, gdy jednocześnie:
1. RM-060 działa (replay backlog po rejoin)
2. RM-061 przechodzi smoke end-to-end
3. `ROADMAP-MASTER-QUEUE.md` ma RM-060 i RM-061 jako `[x]`
4. Progress log zawiera timestamp + artefakty + PASS marker

---

## 6) Aktualny bilans
- Zrobione: **59/61 RM**
- Pozostało: **2 RM**
- Ryzyko: niskie/średnie (głównie poprawna semantyka replay i idempotencja)
- ETA: do domknięcia w bieżącej sesji nocnej

---

## 7) Krótkie podsumowanie jednym zdaniem
Roadmap praktycznie dowieziony; zostało domknąć ostatni odcinek odporności na offline node (replay + final smoke), i temat jest zamknięty end-to-end.
