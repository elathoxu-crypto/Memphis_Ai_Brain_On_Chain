# Memphis Brain Memory Chains

## Cel
Zebrać w jednym miejscu architekturę pomysłów dotyczących Memphis jako „drugiego mózgu”, szczególnie w obszarach: knowledge management, recall, metadata/tagów, szablonów dziennika, bezpieczeństwa vaulta oraz monitoringu cronów/bota. Notatka ma być bazą do zapisania tych założeń w odpowiednich chainach (journal, decisions, vault, ops, project_task) i do późniejszej pracy implementacyjnej.

## Kluczowe założenia i architektura

1. **Knowledge Management (chains: `journal`, `decisions`)**
   - Każdy wpis powinien mieć explicitne metadane: typ, tagi (morning/evening, goal, bugfix, research), związany agent/projekt.
   - Automatyczne sugestie tagów na podstawie NLP (np. analizuj treść, porównaj z dotychczasowymi tagami, zaproponuj). Zapisz historyczny model w `journal` z tagiem `meta-suggestion`.
   - Przywróć rekordy z `decisions` z powiązanymi `project_task`, by recall potrafił odpowiedzieć „dlaczego ta decyzja była podjęta”.

2. **Szablony journala i workflow dewelopera (chains: `journal`, `project_task`)**
   - Rozbij dzień na: morning intention, work log (w tym bugfix) i evening review.
   - Każda sekcja przyporządkuj do tagów; implementuj predefiniowane typy bloków (templatized tags). Automatyzacja: `journal` wstępnie wypełnia sekcje i zachęca do uzupełnienia detali (np. `- [ ] Wpis poranny: ...`).
   - Logi debugów/architektury z flagami `ops`, `build`, `adr` w razie potrzeby.

3. **Recall i kontekst (chains: `journal`, `decisions`, `ops`)**
   - Score wzbogacić o metadane: tags, agents, project. Czyli `recall` rankuje na podstawie: (a) dopasowanie treści, (b) tag priority (np. `security` > `general`), (c) data.
   - Kiedy Urządzenie pyta „co ostatnio działo się z vaultem?”, ECS: wynik musi wskazać `ops` block z alarmem.

4. **Vault + bezpieczeństwo (chain: `vault`, `ops`, `project_task`)**
   - Dodaj workflow rotacji kluczy (cron). Crony generują `ops` block z tagiem `vault-rotation`, a `vault` chain przechowuje zaszyfrowane historyczne dane i przypomnienia.
   - Mechanizm: „rotacja zaplanowana” ↦ `project_task` (zadanie) + `ops` log, po wykonaniu `vault` i `journal` potwierdza.

5. **Monitoring cronów/bota (chains: `ops`, `journal`)**
   - Każdy restart lub fail memphis logowany jako `ops` block (lub `journal` with `log` type) z tagiem „bot-restart/cron”. Przy zapytaniu recall: „czemu memphis restartował się?” – `ops` block plus `journal` wnioski.
   - Status monitor (watchdog) publikuje `ops` block co 24h + `journal` summary.

## Jak użyć w praktyce
1. Zapytania recall powiązać z tagami i agentami (np. `agent=CodeMaster`).
2. Wpisy `journal` powinny odwoływać się do `project_task`/`decision` (linki).
3. Notes z `vault rotation` -> `ops` -> `project_task` tworzy audit trail.
4. Cron alerty, restarty, i statusy zapisuj w `ops`, a w `journal` dodaj refleksje (co zrobiłem, by uniknąć ponownego restartu).

## Kolejne kroki
- Stworzyć automatyczne szablony journalingowe (morning/evening) i przypisać do `decisions` w razie decyzji.
- Zaprojektować scoring recall na meta-danych.
- Ustawić cron rotacji kluczy i monitor botów, logując wszystko w `ops`.

Zachowaj tę notatkę w repozytorium i zrób backup, by można było ją łatwo przeszukiwać i dołączać do nowych `chains`.
