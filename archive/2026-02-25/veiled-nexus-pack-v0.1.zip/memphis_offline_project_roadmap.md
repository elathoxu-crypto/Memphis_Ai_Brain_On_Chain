# Memphis Offline Workflow Project

## 1. Cel projektu
Stworzyć spójny projekt opisujący rolę Style jako jedynego „czytnika” chainów, użytkownika TUI do kluczy i root override oraz dodanie trybu offline w TUI (przełącznik na lokalny model). Całość ma być wsparta klarownym modelem pamięci (chains), planem działania i roadmapą.

## 2. Model operacyjny
| Element | Opis |
| --- | --- |
| **Rola stylu** | Style jednocześnie obserwuje, zapisuje i przygotowuje instrukcje. Wpisy w chainach `journal`, `decisions`, `ops` i `project_task` dokumentują dialog, analizy i decyzje dotyczące offline + bezpieczeństwa. |
| **Rola użytkownika (Ty)** | TUI to Twoje narzędzie do aktów: rotacji kluczy, restartów, edycji root override. Wszystko zrobione powinno być odnotowane przez Style w pamięci. |
| **Offline model** | Lokalna instancja Ollamy (lub inny zaufany LLM) – dostępna jako opcja w TUI „Tryb offline”. Domyślnie działa z lokalnym modelem; w razie potrzeby wraca do zdalnego pipeline. |
| **Pamięć i audyt** | Wpisy w chainach są tagowane (`role:assistant`, `role:user`, `workflow:offline`, `security`, `ops`). Dzięki temu recall może przypomnieć role i kontekst. |

## 3. Roadmapa

### Faza 1 — Discovery (1-2 dni)
1. Zebranie wymagań dla offline toggle i roli (this note + existing memory).
2. Ustalenie, co musi być zapisane w jakim chainie (np. `decisions` dla roli, `ops` dla statusów, `journal` dla obserwacji). 
3. Zdefiniowanie metadanych (tagi) i szablonów, w tym `sync:offline`, `agent:style`, `agent:user`.

**Wyniki:** `project_task` entry z checklistą, `decisions` opisujące finalny workflow.

### Faza 2 — Design (2 dni)
1. Zaprojektować UI TUI: dodać menu *Offline* -> „Tryb lokalny” / „Powrót do chmury”.
2. Określić API switcha (np. `status.model` w `memphis status`, `openclaw configure --model ollama-llama3`).
3. Opisać, jak offline interactuje z chainami: co logować w `ops` (restarty, failover), `vault` (klucze), `journal` (refleksje). 

### Faza 3 — Implementation (3-4 dni)
1. Stworzyć backend TUI command `Config -> Mode -> Offline/Online`. Zmienia `~/.memphis/config.yaml` lub `openclaw configure`. 
2. Dodać `project_task` i `ops` blocks: `offline-mode` toggles, `vault-rotation`, `bot-status`.
3. Ustawić watchdoga: cron `memphis status` co 5 minut, zapis `ops` block w razie zmiany.
4. Bridge: Style zapisuje do `journal` summary przy każdym toggle (np. `tags: [offline-toggle, ops]`).

### Faza 4 — Test & Review (1-2 dni)
1. Test offline switch w TUI (manual, autop run). 
2. Sprawdzenie pamięci: czy `journal`/`ops` logują toggle, `decisions` zachowują kontekst. 
3. Dla bezpieczeństwa: `vault` i `project_task` potwierdzają rotację kluczy po przełączeniu trybu.

### Faza 5 — Launch & Documentation
1. Zaktualizować dokumentację `memphis_brain_memory_chains.md`, `memphis_offline_project_roadmap.md` i `memo` w `journal`.
2. Przekazać użytkownikowi instrukcję obsługi TUI offline + przypomnieć o tagach metadata. 
3. Dodać `memory/2026-02-24.md` entry (już jest, ale dopisuję nowy bullet w kolejnym zapisie z roadmapą?).

## 4. Checklisty (Project Tasks)
1. `project_task: offline-setup` – implementacja toggla, `ops` log, `journal` summary.
2. `project_task: metadata-template` – predefiniowane tagi + recall scoring.
3. `project_task: security-audit` – ensure they are recorded, log vault rotation.

## 5. Mierniki sukcesu
- TUI posiada widoczną opcję „Offline” i przełącza model.
- Każdy przełącznik zapisany w `ops` + `journal` + `project_task`, tagi `offline-toggle` i `agent:style` widoczne w recall.
- Vault rotacja i watchdog status (cron) są przewidywalne, a logger (Style) potrafi opisać przebieg.

## 6. Kolejne kroki pamięciowe
- Po każdym przełączeniu: `journal` (Style) dopisuje refleksję + `ops` block. 
- `decisions` dokumentuje, że to Ty (TUI) wykonujesz root override, a ja monitoruję.
- `memo`/`memory/2026-02-24.md` (kolejny wpis) przypomina: offline mode + rola.
