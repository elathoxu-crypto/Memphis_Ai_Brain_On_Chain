# Notes — Projekt status i next steps
**Data:** 2026-03-07 05:21 CET

## 1) Status końcowy roadmapy
- RM-001 → RM-061: **DONE**
- Brak otwartych pozycji `[ ]` w `ROADMAP-MASTER-QUEUE.md`
- Końcowe smoki zaliczone:
  - `SMOKE_RM060_OK`
  - `SMOKE_RM061_OK offline defer -> online resume`
  - `SMOKE_DISTRIBUTED_RUNTIME_OK`

## 2) Co zostało dowiezione na końcu (M8)
- **RM-060:** backlog replay po powrocie node-b (deferred -> queued)
- **RM-061:** pełny smoke flow offline/online (`offline defer -> online resume`)

## 3) Najważniejsze zmiany kodowe
- `gateway-runtime/src/state/store.mjs`
  - dodane `replayDeferredToQueued(...)`
  - sortowanie replay po `deferred_at`
  - deduplikacja po `task_id`/`idempotency_key`
- `gateway-runtime/src/scheduler/index.mjs`
  - `replayDeferredIfRecovered()` zwraca teraz metryki (`count`, `recovered`, `ts`)
- nowe smoke testy:
  - `gateway-runtime/scripts/smoke-rm060.mjs`
  - `gateway-runtime/scripts/smoke-rm061.mjs`
- rozszerzony runtime smoke:
  - `gateway-runtime/scripts/smoke-distributed-runtime.mjs` (RM-057/058/060/061)
- update:
  - `gateway-runtime/package.json`
  - `gateway-runtime/README.md`

## 4) Artefakty do przekazania
- ZIP statusowy:
  - `ROADMAP-STATUS-2026-03-07.zip`
- ZIP delivery (kod + testy + roadmap):
  - `RM061-DELIVERY-PACKAGE-2026-03-07.zip`
- Raport opisowy:
  - `ROADMAP-STATUS-OBSZERNIE-2026-03-07.md`

## 5) Ryzyka / uwagi operacyjne
- Repo główne w tym katalogu nie jest Git repo (`.git` brak), więc push/commit trzeba robić w docelowym repo lub właściwej ścieżce projektu.
- `memphis share-sync` nadal może wymagać poprawnej konfiguracji SSH key (`Permission denied (publickey)`) — nie krytyczne dla zamknięcia roadmapy runtime, ale warto poprawić dla pełnej synchronizacji.

## 6) Rekomendowane następne kroki (opcjonalne)
1. Deployment na środowisko docelowe.
2. Smoke po deployu (powtórzyć full runtime smoke).
3. Snapshot/release notes (wersja, lista zmian, test evidence).
4. Start kolejnej kolejki RM-062+ (jeśli priorytety gotowe).

## 7) One-liner status
Roadmap dowieziony end-to-end (61/61), kod i smoke testy potwierdzone, paczka delivery gotowa.
